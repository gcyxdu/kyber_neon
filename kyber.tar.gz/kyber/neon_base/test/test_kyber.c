#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "../kem.h"
#include "../randombytes.h"

#define NTESTS 1000

// 打印 32 字节密钥的十六进制（方便对比）
static void print_hex(const char *label, const uint8_t *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
        if (i % 16 == 15) printf("\n          ");
    }
    printf("\n");
}

static int test_keys(int test_id) {
    uint8_t pk[CRYPTO_PUBLICKEYBYTES];
    uint8_t sk[CRYPTO_SECRETKEYBYTES];
    uint8_t ct[CRYPTO_CIPHERTEXTBYTES];
    uint8_t key_a[CRYPTO_BYTES];
    uint8_t key_b[CRYPTO_BYTES];

    // Alice 生成公钥
    crypto_kem_keypair(pk, sk);

    // Bob 封装得到密文和共享密钥 key_b
    crypto_kem_enc(ct, key_b, pk);

    // Alice 解封装得到共享密钥 key_a
    crypto_kem_dec(key_a, ct, sk);

    if (memcmp(key_a, key_b, CRYPTO_BYTES)) {
        printf("\n[ERROR] test_keys #%d failed!\n", test_id);
        printf("Alice's key_a and Bob's key_b do NOT match!\n");
        print_hex("key_a (Alice)", key_a, CRYPTO_BYTES);
        print_hex("key_b (Bob) ", key_b, CRYPTO_BYTES);
        return 1;
    }

    return 0;
}

static int test_invalid_sk_a(int test_id) {
    uint8_t pk[CRYPTO_PUBLICKEYBYTES];
    uint8_t sk[CRYPTO_SECRETKEYBYTES];
    uint8_t ct[CRYPTO_CIPHERTEXTBYTES];
    uint8_t key_a[CRYPTO_BYTES];
    uint8_t key_b[CRYPTO_BYTES];

    crypto_kem_keypair(pk, sk);
    crypto_kem_enc(ct, key_b, pk);

    // 故意破坏 sk
    randombytes(sk, CRYPTO_SECRETKEYBYTES);

    crypto_kem_dec(key_a, ct, sk);

    if (!memcmp(key_a, key_b, CRYPTO_BYTES)) {
        printf("\n[ERROR] test_invalid_sk_a #%d failed!\n", test_id);
        printf("Invalid secret key still produced the same shared key!\n");
        print_hex("key_a (with invalid sk)", key_a, CRYPTO_BYTES);
        print_hex("key_b (original)         ", key_b, CRYPTO_BYTES);
        return 1;
    }

    return 0;
}

static int test_invalid_ciphertext(int test_id) {
    uint8_t pk[CRYPTO_PUBLICKEYBYTES];
    uint8_t sk[CRYPTO_SECRETKEYBYTES];
    uint8_t ct[CRYPTO_CIPHERTEXTBYTES];
    uint8_t key_a[CRYPTO_BYTES];
    uint8_t key_b[CRYPTO_BYTES];
    uint8_t b;
    size_t pos;

    do {
        randombytes(&b, sizeof(uint8_t));
    } while (!b);
    randombytes((uint8_t *)&pos, sizeof(size_t));

    crypto_kem_keypair(pk, sk);
    crypto_kem_enc(ct, key_b, pk);

    // 破坏密文
    ct[pos % CRYPTO_CIPHERTEXTBYTES] ^= b;

    crypto_kem_dec(key_a, ct, sk);

    if (!memcmp(key_a, key_b, CRYPTO_BYTES)) {
        printf("\n[ERROR] test_invalid_ciphertext #%d failed!\n", test_id);
        printf("Invalid ciphertext still produced the same shared key!\n");
        printf("Modified byte at position %zu (value changed by 0x%02x)\n", pos % CRYPTO_CIPHERTEXTBYTES, b);
        print_hex("key_a (with invalid ct)", key_a, CRYPTO_BYTES);
        print_hex("key_b (original)         ", key_b, CRYPTO_BYTES);
        return 1;
    }

    return 0;
}

int main(void) {
    unsigned int i;
    int r = 0;

    printf("Starting Kyber-512 KAT tests (%d iterations)...\n", NTESTS);

    for (i = 0; i < NTESTS; i++) {
        if (i % 100 == 0 && i > 0) {
            printf("Progress: %d / %d tests passed so far...\n", i, NTESTS);
        }

        r |= test_keys(i);
        r |= test_invalid_sk_a(i);
        r |= test_invalid_ciphertext(i);

        if (r) {
            printf("Test failed at iteration %d! Stopping.\n", i);
            break;
        }
    }

    if (r == 0) {
        printf("\nAll %d tests PASSED!\n", NTESTS);
    } else {
        printf("\nSome tests FAILED! See above for details.\n");
    }

    printf("CRYPTO_SECRETKEYBYTES:  %d\n", CRYPTO_SECRETKEYBYTES);
    printf("CRYPTO_PUBLICKEYBYTES:  %d\n", CRYPTO_PUBLICKEYBYTES);
    printf("CRYPTO_CIPHERTEXTBYTES: %d\n", CRYPTO_CIPHERTEXTBYTES);

    return r ? 1 : 0;
}
