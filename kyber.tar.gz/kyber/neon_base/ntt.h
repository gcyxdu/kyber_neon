/*
#ifndef NTT_H
#define NTT_H

#include <stdint.h>
#include "params.h"
// 补充 NEON 类型声明（可选，确保向量类型可见）
#include <arm_neon.h>

// 保持与 Ref 版一致的命名空间宏（兼容原有代码）
#ifndef KYBER_NAMESPACE
#define KYBER_NAMESPACE(x) x
#endif

// zetas 数组声明（长度/命名完全对齐 Ref 版）
#define zetas KYBER_NAMESPACE(zetas)
extern const int16_t zetas[128];

// 核心函数签名完全不变（对外接口兼容 Ref 版，内部纯向量实现）
void ntt(int16_t r[KYBER_N]);
void invntt(int16_t r[KYBER_N]);

// basemul 函数声明：保持 Ref 版签名，内部已改为向量实现
void basemul(int16_t r[2], const int16_t a[2], const int16_t b[2], int16_t zeta);

#endif
*/
#ifndef NTT_H
#define NTT_H

#include <stdint.h>
#include "params.h"

#define zetas KYBER_NAMESPACE(zetas)
extern const int16_t zetas[128];

#define ntt KYBER_NAMESPACE(ntt)
void ntt(int16_t poly[256]);

#define invntt KYBER_NAMESPACE(invntt)
void invntt(int16_t poly[256]);

#define basemul KYBER_NAMESPACE(basemul)
void basemul(int16_t r[2], const int16_t a[2], const int16_t b[2], int16_t zeta);

#endif
