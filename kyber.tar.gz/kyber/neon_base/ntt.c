/*
#include <stdint.h>
#include "params.h"
#include "ntt.h"
#include "reduce.h"
#include <arm_neon.h>

// zetas 数组保持原样
const int16_t zetas[128] = {
  -1044, -758, -359, -1517, 1493, 1422, 287, 202,
   -171, 622, 1577, 182, 962, -1202, -1474, 1468,
    573, -1325, 264, 383, -829, 1458, -1602, -130,
   -681, 1017, 732, 608, -1542, 411, -205, -1571,
   1223, 652, -552, 1015, -1293, 1491, -282, -1544,
    516, -8, -320, -666, -1618, -1162, 126, 1469,
   -853, -90, -271, 830, 107, -1421, -247, -951,
   -398, 961, -1508, -725, 448, -1065, 677, -1275,
  -1103, 430, 555, 843, -1251, 871, 1550, 105,
    422, 587, 177, -235, -291, -460, 1574, 1653,
   -246, 778, 1159, -147, -777, 1483, -602, 1119,
  -1590, 644, -872, 349, 418, 329, -156, -75,
    817, 1097, 603, 610, 1322, -1285, -1465, 384,
  -1215, -136, 1218, -1335, -874, 220, -1187, -1659,
  -1185, -1530, -1278, 794, -1510, -854, -870, 478,
   -108, -308, 996, 991, 958, -1460, 1522, 1628
};

// 向量版 fqmul（4 lane）
static inline int16x4_t fqmul_4lane(int16x4_t a, int16_t zeta) {
    int32x4_t prod = vmull_n_s16(a, zeta);
    return montgomery_reduce(prod);
}

// 向量版 fqmul（8 lane，拆分为 4+4）
static inline int16x8_t fqmul_8lane(int16x8_t a, int16_t zeta) {
    int16x4_t a_low = vget_low_s16(a);
    int16x4_t a_high = vget_high_s16(a);
    
    int16x4_t res_low = fqmul_4lane(a_low, zeta);
    int16x4_t res_high = fqmul_4lane(a_high, zeta);
    
    return vcombine_s16(res_low, res_high);
}

// 纯向量 NTT 蝶形（4 lane，无标量分支）
static inline void ntt_butterfly_4lane(int16_t *aptr, int16_t *bptr, int16_t zeta) {
    int16x4_t a = vld1_s16(aptr);
    int16x4_t b = vld1_s16(bptr);
    
    int16x4_t t = fqmul_4lane(b, zeta);
    
    int16x4_t new_b = vsub_s16(a, t);
    int16x4_t new_a = vadd_s16(a, t);
    
    vst1_s16(aptr, new_a);
    vst1_s16(bptr, new_b);
}

// 纯向量 INVNTT 蝶形（8 lane，无标量分支）
static inline void invntt_butterfly_8lane(int16_t *aptr, int16_t *bptr, int16_t zeta) {
    int16x8_t a = vld1q_s16(aptr);
    int16x8_t b = vld1q_s16(bptr);
    
    // 对齐 Ref 版逻辑：sum = a + b, diff = b - a
    int16x8_t sum = vaddq_s16(a, b);
    int16x8_t diff = vsubq_s16(b, a);
    
    // 8 lane 巴雷特约简
    int16x8_t new_a = barrett_reduce(sum);
    diff = barrett_reduce(diff);
    
    // 8 lane 蒙哥马利乘法
    int16x8_t new_b = fqmul_8lane(diff, zeta);
    
    vst1q_s16(aptr, new_a);
    vst1q_s16(bptr, new_b);
}

// 纯向量版 NTT（无标量分支，KYBER_N=256 是 4 的整数倍）
void ntt(int16_t r[256]) {
    unsigned int len, start, j, k = 1;

    // KYBER_N=256 是 4 的整数倍，无需标量兜底
    for (len = 128; len >= 4; len >>= 1) {
        for (start = 0; start < 256; start += len * 2) {
            int16_t zeta = zetas[k++];
            // 4 lane 批量处理（256/4=64 次，无剩余）
            for (j = start; j < start + len; j += 4) {
                ntt_butterfly_4lane(&r[j], &r[j + len], zeta);
            }
        }
    }
    
    // 处理 len=2（最后一层，仍用 4 lane 拆分）
    len = 2;
    for (start = 0; start < 256; start += len * 2) {
        int16_t zeta = zetas[k++];
        // 4 lane 处理（每次处理 2 组 len=2 的蝶形）
        for (j = start; j < start + len; j += 4) {
            // 第1组蝶形（j, j+2）
            int16x4_t a = vld1_s16(&r[j]);
            int16x4_t b = vld1_s16(&r[j + len]);
            
            int16x4_t t = fqmul_4lane(b, zeta);
            
            int16x4_t new_b = vsub_s16(a, t);
            int16x4_t new_a = vadd_s16(a, t);
            
            vst1_s16(&r[j], new_a);
            vst1_s16(&r[j + len], new_b);
        }
    }
}

// 纯向量版 INVNTT（无标量分支，KYBER_N=256 是 8 的整数倍）
void invntt(int16_t r[256]) {
    unsigned int start, len, j, k = 0;
    const int16_t f = 1441;

    // 处理 len=2~64（8 lane 批量处理）
    for (len = 2; len <= 64; len <<= 1) {
        for (start = 0; start < 256; start += len * 2) {
            int16_t zeta = zetas[127 - k];
            // 8 lane 批量处理（256/8=32 次，无剩余）
            for (j = start; j < start + len; j += 8) {
                invntt_butterfly_8lane(&r[j], &r[j + len], zeta);
            }
            k++;
        }
    }
    
    // 处理 len=128（最后一层，8 lane 处理）
    len = 128;
    for (start = 0; start < 256; start += len * 2) {
        int16_t zeta = zetas[127 - k];
        for (j = start; j < start + len; j += 8) {
            invntt_butterfly_8lane(&r[j], &r[j + len], zeta);
        }
        k++;
    }

    // 最后乘 f（纯 8 lane 向量运算）
    for (j = 0; j < 256; j += 8) {
        int16x8_t vec = vld1q_s16(&r[j]);
        int16x8_t res = fqmul_8lane(vec, f);
        vst1q_s16(&r[j], res);
    }
}

// 纯向量版 basemul（拆分为 2 lane 向量运算，对齐 4 lane 约简）
void basemul(int16_t r[2], const int16_t a[2], const int16_t b[2], int16_t zeta) {
    // 补齐为 4 lane 向量（后两位填 0，不影响结果）
    int16_t a_pad[4] = {a[0], a[1], 0, 0};
    int16_t b_pad[4] = {b[0], b[1], 0, 0};
    
    int16x4_t a_vec = vld1_s16(a_pad);
    int16x4_t b_vec = vld1_s16(b_pad);
    
    // 计算 a[1]*b[1]（取向量第2位）
    int16x4_t a1b1 = vmul_s16(vdup_n_s16(vget_lane_s16(a_vec, 1)), 
                              vdup_n_s16(vget_lane_s16(b_vec, 1)));
    int16x4_t r0_1 = fqmul_4lane(a1b1, zeta);
    
    // 计算 a[0]*b[0]（取向量第1位）
    int16x4_t a0b0 = vmul_s16(vdup_n_s16(vget_lane_s16(a_vec, 0)), 
                              vdup_n_s16(vget_lane_s16(b_vec, 0)));
    int16x4_t r0_2 = fqmul_4lane(a0b0, 1); // zeta=1
    
    // r[0] = r0_1 + r0_2
    int16x4_t r0 = vadd_s16(r0_1, r0_2);
    
    // 计算 a[0]*b[1] + a[1]*b[0]
    int16x4_t a0b1 = vmul_s16(vdup_n_s16(vget_lane_s16(a_vec, 0)), 
                              vdup_n_s16(vget_lane_s16(b_vec, 1)));
    int16x4_t a1b0 = vmul_s16(vdup_n_s16(vget_lane_s16(a_vec, 1)), 
                              vdup_n_s16(vget_lane_s16(b_vec, 0)));
    int16x4_t r1_1 = fqmul_4lane(a0b1, 1);
    int16x4_t r1_2 = fqmul_4lane(a1b0, 1);
    int16x4_t r1 = vadd_s16(r1_1, r1_2);
    
    // 提取结果（忽略补齐的 0）
    r[0] = vget_lane_s16(r0, 0);
    r[1] = vget_lane_s16(r1, 0);
}
*/
#include <stdint.h>
#include "params.h"
#include "ntt.h"
#include "reduce.h"

/* Code to generate zetas and zetas_inv used in the number-theoretic transform:

#define KYBER_ROOT_OF_UNITY 17

static const uint8_t tree[128] = {
  0, 64, 32, 96, 16, 80, 48, 112, 8, 72, 40, 104, 24, 88, 56, 120,
  4, 68, 36, 100, 20, 84, 52, 116, 12, 76, 44, 108, 28, 92, 60, 124,
  2, 66, 34, 98, 18, 82, 50, 114, 10, 74, 42, 106, 26, 90, 58, 122,
  6, 70, 38, 102, 22, 86, 54, 118, 14, 78, 46, 110, 30, 94, 62, 126,
  1, 65, 33, 97, 17, 81, 49, 113, 9, 73, 41, 105, 25, 89, 57, 121,
  5, 69, 37, 101, 21, 85, 53, 117, 13, 77, 45, 109, 29, 93, 61, 125,
  3, 67, 35, 99, 19, 83, 51, 115, 11, 75, 43, 107, 27, 91, 59, 123,
  7, 71, 39, 103, 23, 87, 55, 119, 15, 79, 47, 111, 31, 95, 63, 127
};

void init_ntt() {
  unsigned int i;
  int16_t tmp[128];

  tmp[0] = MONT;
  for(i=1;i<128;i++)
    tmp[i] = fqmul(tmp[i-1],MONT*KYBER_ROOT_OF_UNITY % KYBER_Q);

  for(i=0;i<128;i++) {
    zetas[i] = tmp[tree[i]];
    if(zetas[i] > KYBER_Q/2)
      zetas[i] -= KYBER_Q;
    if(zetas[i] < -KYBER_Q/2)
      zetas[i] += KYBER_Q;
  }
}
*/

const int16_t zetas[128] = {
  -1044,  -758,  -359, -1517,  1493,  1422,   287,   202,
   -171,   622,  1577,   182,   962, -1202, -1474,  1468,
    573, -1325,   264,   383,  -829,  1458, -1602,  -130,
   -681,  1017,   732,   608, -1542,   411,  -205, -1571,
   1223,   652,  -552,  1015, -1293,  1491,  -282, -1544,
    516,    -8,  -320,  -666, -1618, -1162,   126,  1469,
   -853,   -90,  -271,   830,   107, -1421,  -247,  -951,
   -398,   961, -1508,  -725,   448, -1065,   677, -1275,
  -1103,   430,   555,   843, -1251,   871,  1550,   105,
    422,   587,   177,  -235,  -291,  -460,  1574,  1653,
   -246,   778,  1159,  -147,  -777,  1483,  -602,  1119,
  -1590,   644,  -872,   349,   418,   329,  -156,   -75,
    817,  1097,   603,   610,  1322, -1285, -1465,   384,
  -1215,  -136,  1218, -1335,  -874,   220, -1187, -1659,
  -1185, -1530, -1278,   794, -1510,  -854,  -870,   478,
   -108,  -308,   996,   991,   958, -1460,  1522,  1628
};

/*************************************************
* Name:        fqmul
*
* Description: Multiplication followed by Montgomery reduction
*
* Arguments:   - int16_t a: first factor
*              - int16_t b: second factor
*
* Returns 16-bit integer congruent to a*b*R^{-1} mod q
**************************************************/
static int16_t fqmul(int16_t a, int16_t b) {
  return montgomery_reduce((int32_t)a*b);
}

/*************************************************
* Name:        ntt
*
* Description: Inplace number-theoretic transform (NTT) in Rq.
*              input is in standard order, output is in bitreversed order
*
* Arguments:   - int16_t r[256]: pointer to input/output vector of elements of Zq
**************************************************/
void ntt(int16_t r[256]) {
  unsigned int len, start, j, k;
  int16_t t, zeta;

  k = 1;
  for(len = 128; len >= 2; len >>= 1) {
    for(start = 0; start < 256; start = j + len) {
      zeta = zetas[k++];
      for(j = start; j < start + len; j++) {
        t = fqmul(zeta, r[j + len]);
        r[j + len] = r[j] - t;
        r[j] = r[j] + t;
      }
    }
  }
}

/*************************************************
* Name:        invntt_tomont
*
* Description: Inplace inverse number-theoretic transform in Rq and
*              multiplication by Montgomery factor 2^16.
*              Input is in bitreversed order, output is in standard order
*
* Arguments:   - int16_t r[256]: pointer to input/output vector of elements of Zq
**************************************************/
void invntt(int16_t r[256]) {
  unsigned int start, len, j, k;
  int16_t t, zeta;
  const int16_t f = 1441; // mont^2/128

  k = 127;
  for(len = 2; len <= 128; len <<= 1) {
    for(start = 0; start < 256; start = j + len) {
      zeta = zetas[k--];
      for(j = start; j < start + len; j++) {
        t = r[j];
        r[j] = barrett_reduce(t + r[j + len]);
        r[j + len] = r[j + len] - t;
        r[j + len] = fqmul(zeta, r[j + len]);
      }
    }
  }

  for(j = 0; j < 256; j++)
    r[j] = fqmul(r[j], f);
}


/*************************************************
* Name:        basemul
*
* Description: Multiplication of polynomials in Zq[X]/(X^2-zeta)
*              used for multiplication of elements in Rq in NTT domain
*
* Arguments:   - int16_t r[2]: pointer to the output polynomial
*              - const int16_t a[2]: pointer to the first factor
*              - const int16_t b[2]: pointer to the second factor
*              - int16_t zeta: integer defining the reduction polynomial
**************************************************/
void basemul(int16_t r[2], const int16_t a[2], const int16_t b[2], int16_t zeta)
{
  r[0]  = fqmul(a[1], b[1]);
  r[0]  = fqmul(r[0], zeta);
  r[0] += fqmul(a[0], b[0]);
  r[1]  = fqmul(a[0], b[1]);
  r[1] += fqmul(a[1], b[0]);
}
