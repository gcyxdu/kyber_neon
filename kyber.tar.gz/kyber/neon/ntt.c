#include <stdio.h>
#include <stdint.h>
#include "params.h"
#include "ntt.h"
#include "reduce.h"
#include <arm_neon.h>


const int16_t zetas[128] = {
  -1044,  -758,  -359, -1517,  1493,  1422,   287,   202,
   -171,   622,  1577,   182,   962, -1202, -1474,  1468,
    573, -1325,   264,   383,  -829,  1458, -1602,  -130,
   -681,  1017,   732,   608, -1542,   411,  -205, -1571,
   1223,   652,  -552,  1015, -1293,  1491,  -282, -1544,
    516,    -8,  -320,  -666, -1618, -1162,   126,  1469,
   -853,   -90,  -271,   830,   107, -1421,  -247,  -951,
   -398,   961, -1508,  -725,   448, -1065,   677, -1275,
  -1103,   430,   555,   843, -1251,   871,  1550,   105,
    422,   587,   177,  -235,  -291,  -460,  1574,  1653,
   -246,   778,  1159,  -147,  -777,  1483,  -602,  1119,
  -1590,   644,  -872,   349,   418,   329,  -156,   -75,
    817,  1097,   603,   610,  1322, -1285, -1465,   384,
  -1215,  -136,  1218, -1335,  -874,   220, -1187, -1659,
  -1185, -1530, -1278,   794, -1510,  -854,  -870,   478,
   -108,  -308,   996,   991,   958, -1460,  1522,  1628
};


static int16_t fqmul(int16_t a, int16_t b) {
  return montgomery_reduce((int32_t)a*b);
}

static inline int16x4_t fqmul_4lane(int16x4_t a, int16x4_t b){
  int32x4_t prod = vmull_s16(a, b);
  return montgomery_reduce_neon(prod);

}

static inline int16x8_t fqmul_8lane(int16x8_t a, int16x8_t b){
  int16x4_t a_low = vget_low_s16(a);
  int16x4_t a_high = vget_high_s16(a);
  int16x4_t b_low = vget_low_s16(b);
  int16x4_t b_high = vget_high_s16(b);
  
  int16x4_t res_low = fqmul_4lane(a_low, b_low);
  int16x4_t res_high = fqmul_4lane(a_high, b_high);
  
  return vcombine_s16(res_low, res_high);
}



static inline void ntt_butterfly_4lane(int16_t *aptr, int16_t *bptr, int16_t zeta) {
    int16x4_t a = vld1_s16(aptr);          // r[j]
    int16x4_t b = vld1_s16(bptr);          // r[j + len]

    int16x4_t t = fqmul_4lane(b, vdup_n_s16(zeta));  // t = fqmul(zeta, r[j+len])

    int16x4_t new_b = vsub_s16(a, t);     // r[j+len] = r[j] - t
    int16x4_t new_a = vadd_s16(a, t);     // r[j] = r[j] + t

    vst1_s16(aptr, new_a);
    vst1_s16(bptr, new_b);
}

static inline void invntt_butterfly_8lane(int16_t *aptr, int16_t *bptr, int16_t zeta) {
    int16x8_t a = vld1q_s16(aptr);          // r[j]   (旧值)
    int16x8_t b = vld1q_s16(bptr);          // r[j + len] (旧值)

    int16x8_t t = a;                        // t = r[j] (旧值)

    // 1. r[j] = barrett_reduce(t + r[j + len])   ← 先约简和
    int16x8_t sum = vaddq_s16(t, b);
    int16x8_t new_a = barrett_reduce_neon(sum);

    // 2. r[j + len] = r[j + len] - t             ← 减法基于旧 b
    int16x8_t diff = vsubq_s16(b, t);

    // 3. r[j + len] = fqmul(zeta, diff)          ← 直接乘（fqmul 内部约简）
    int16x8_t new_b = fqmul_8lane(diff, vdupq_n_s16(zeta));

    vst1q_s16(aptr, new_a);
    vst1q_s16(bptr, new_b);
}

void ntt(int16_t r[256]) {
    unsigned int len, start, j, k = 1;
    int16_t zeta;

    
    for (len = 128; len >= 4; len >>= 1) {
        for (start = 0; start < 256; start += len * 2) {
            zeta = zetas[k++];
            j = start;
            while (j + 3 < start + len) {  
                ntt_butterfly_4lane(&r[j], &r[j + len], zeta);
                j += 4;
            }
            
            for (; j < start + len; j++) {
                int16_t t = fqmul(zeta, r[j + len]);
                r[j + len] = r[j] - t;
                r[j] = r[j] + t;
            }
        }
    }

    
    len = 2;
    for (start = 0; start < 256; start += len * 2) {
        zeta = zetas[k++];
        for (j = start; j < start + len; j++) {
            int16_t t = fqmul(zeta, r[j + len]);
            r[j + len] = r[j] - t;
            r[j] = r[j] + t;
        }
    }
}



void invntt(int16_t r[KYBER_N]) {
    unsigned int start, len, j;
    unsigned int k = 127;           
    const int16_t f = 1441;          
    const int16x8_t f_vec = vdupq_n_s16(f); 

    // 外层循环：分层处理（len从2倍增到128）
    for (len = 2; len <= 128; len <<= 1) {
        // 中层循环：按len分组处理
        for (start = 0; start < KYBER_N; start = j + len) {
            int16_t zeta = zetas[k--]; // 取当前层旋转因子
            j = start;

            // 1. len >=16 时用8-lane批量处理
            if (len >= 16) {
                // 批量处理8个元素的块，避免越界
                for (; j + 7 < start + len; j += 8) {
                    invntt_butterfly_8lane(&r[j], &r[j + len], zeta);
                }
            }

            // 2. 剩余元素 + len<16 小层
            for (; j < start + len; j++) {
                int16_t t = r[j];
                r[j] = barrett_reduce(t + r[j + len]);
                r[j + len] = r[j + len] - t;
                r[j + len] = fqmul(zeta, r[j + len]);
            }
        }
    }

    // 3. 最后归一化：所有系数乘以f
    for (j = 0; j < KYBER_N; j += 8) {
        int16x8_t r_vec = vld1q_s16(&r[j]);
        r_vec = fqmul_8lane(r_vec, f_vec); 
        vst1q_s16(&r[j], r_vec);
    }
}




void basemul(int16_t r[2], const int16_t a[2], const int16_t b[2], int16_t zeta)
{
    int16x4_t avec = vld1_s16(a);  // a0, a1, 0, 0
    int16x4_t bvec = vld1_s16(b);  // b0, b1, 0, 0

    int16x4_t a0 = vdup_lane_s16(avec, 0);
    int16x4_t a1 = vdup_lane_s16(avec, 1);
    int16x4_t b0 = vdup_lane_s16(bvec, 0);
    int16x4_t b1 = vdup_lane_s16(bvec, 1);

    // 计算 4 个乘积
    int32x4_t p0 = vmull_s16(a0, b0);  // a0 b0
    int32x4_t p1 = vmull_s16(a1, b1);  // a1 b1
    int32x4_t p2 = vmull_s16(a0, b1);  // a0 b1
    int32x4_t p3 = vmull_s16(a1, b0);  // a1 b0

    // r[0] = mont(a0 b0) + zeta * mont(a1 b1)
    int16x4_t r0 = montgomery_reduce_neon(p0);
    int16x4_t tmp = montgomery_reduce_neon(p1);
    tmp = montgomery_reduce_neon(vmull_n_s16(tmp, zeta));
    r0 = vadd_s16(r0, tmp);

    // r[1] = mont(a0 b1) + mont(a1 b0)
    int16x4_t r1 = vadd_s16(montgomery_reduce_neon(p2), montgomery_reduce_neon(p3));

    r[0] = barrett_reduce(vget_lane_s16(r0, 0));
    r[1] = barrett_reduce(vget_lane_s16(r1, 0));
   

}

