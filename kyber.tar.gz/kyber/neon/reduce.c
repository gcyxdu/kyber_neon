
#include <stdint.h>
#include "params.h"
#include "reduce.h"
#include <arm_neon.h>
int16_t montgomery_reduce(int32_t a)
{
  int16_t t;

  t = (int16_t)a*QINV;
  t = (a - (int32_t)t*KYBER_Q) >> 16;
  return t;
}

int16_t barrett_reduce(int16_t a) {
  int16_t t;
  const int16_t v = ((1<<26) + KYBER_Q/2)/KYBER_Q;

  t  = ((int32_t)v*a + (1<<25)) >> 26;
  t *= KYBER_Q;
  return a - t;
}


int16x4_t montgomery_reduce_neon(int32x4_t a)
{
  const int16x4_t qinv = vdup_n_s16(QINV);
  const int32x4_t q = vdupq_n_s32(KYBER_Q);
  
  int16x4_t a_low = vmovn_s32(a);
  
  int16x4_t t = vmul_s16(a_low, qinv);
  
  int32x4_t t_wide = vmovl_s16(t);
  int32x4_t u = vmulq_s32(t_wide, q);
  
  int32x4_t d = vsubq_s32(a, u);
  
  return vshrn_n_s32(d, 16);
  
}


int16x8_t barrett_reduce_neon(int16x8_t a)
{
    const int16x8_t q     = vdupq_n_s16(KYBER_Q);
    const int16x8_t v_vec = vdupq_n_s16(20159);
    const int32x4_t offset = vdupq_n_s32(1 << 25);

    int16x4_t a_low  = vget_low_s16(a);
    int16x4_t a_high = vget_high_s16(a);

    int32x4_t al = vmull_s16(a_low,  vget_low_s16(v_vec));
    int32x4_t ah = vmull_s16(a_high, vget_high_s16(v_vec));

    al = vaddq_s32(al, offset);
    ah = vaddq_s32(ah, offset);

    int32x4_t ql32 = vshrq_n_s32(al,  26);
    int32x4_t qh32 = vshrq_n_s32(ah,  26);

    int16x4_t ql16 = vmovn_s32(ql32);
    int16x4_t qh16 = vmovn_s32(qh32);

    int16x8_t quot = vcombine_s16(ql16, qh16);

    int16x8_t t = vmulq_s16(quot, q);

    return vsubq_s16(a, t);





}
