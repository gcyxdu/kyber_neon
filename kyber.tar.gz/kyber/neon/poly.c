#include <stdint.h>
#include "params.h"
#include "poly.h"
#include "ntt.h"
#include "reduce.h"
#include "cbd.h"
#include "symmetric.h"
#include "verify.h"
#include<arm_neon.h>
/*poly_compress函数
c语言实现分为128字节和160字节两种情况。
1.将负数映射为正数。（方法是右移15位，和KYBER_Q 按位与后加到原数）
2.系数缩放到4bit(0~15)或者5bit(0~31)。8个系数打包为4字节或者5字节。
（方法是用定点数近似除法代替/3329*16或者/3329*32的浮点除法，避免精度损失。）
*/
/*neon优化思路
1.用 NEON 128 位寄存器批量加载 8 个系数（vld1q_s16）；
2.批量映射负数为正数；
3.批量执行缩放计算（移位 + 加法 + 乘法 + 右移）；
4.批量打包压缩后的 bit 到字节数组。
*/ 


void poly_compress(uint8_t r[KYBER_POLYCOMPRESSEDBYTES], const poly *a)
{
    unsigned int i;
    int16x8_t vec_q = vdupq_n_s16(KYBER_Q);

#if KYBER_POLYCOMPRESSEDBYTES == 128
    uint32x4_t vec_1665 = vdupq_n_u32(1665);
    uint32x4_t vec_80635 = vdupq_n_u32(80635);
    for (i = 0; i < KYBER_N / 8; i++) {
        int16x8_t vec_u = vld1q_s16(&a->coeffs[8 * i]);

        // 负数映射为正数
        int16x8_t sign = vshrq_n_s16(vec_u, 15);
        sign = vandq_s16(sign, vec_q);
        vec_u = vaddq_s16(vec_u, sign);

        // 定点数缩放
        uint32x4_t d0 = vmovl_u16(vget_low_u16(vreinterpretq_u16_s16(vec_u)));
        uint32x4_t d1 = vmovl_u16(vget_high_u16(vreinterpretq_u16_s16(vec_u)));
        d0 = vshlq_n_u32(d0, 4); d0 = vaddq_u32(d0, vec_1665);
        d1 = vshlq_n_u32(d1, 4); d1 = vaddq_u32(d1, vec_1665);
        d0 = vmulq_u32(d0, vec_80635);
        d1 = vmulq_u32(d1, vec_80635);
        d0 = vshrq_n_u32(d0, 28);
        d1 = vshrq_n_u32(d1, 28);
        d0 = vandq_u32(d0, vdupq_n_u32(0xF));
        d1 = vandq_u32(d1, vdupq_n_u32(0xF));

        // narrow 到 8 个 nibble
        uint16x4_t n0 = vmovn_u32(d0);
        uint16x4_t n1 = vmovn_u32(d1);
        uint8x8_t t = vmovn_u16(vcombine_u16(n0, n1));

        
        uint8_t tmp[8];
        vst1_u8(tmp, t);

        r[0] = tmp[0] | (tmp[1] << 4);
        r[1] = tmp[2] | (tmp[3] << 4);
        r[2] = tmp[4] | (tmp[5] << 4);
        r[3] = tmp[6] | (tmp[7] << 4);
        r += 4;
    }
#elif KYBER_POLYCOMPRESSEDBYTES == 160
    uint32x4_t vec_add = vdupq_n_u32(1664);
    uint32x4_t vec_mul = vdupq_n_u32(40318);
    for (i = 0; i < KYBER_N / 8; i++) {
        int16x8_t vec_u = vld1q_s16(&a->coeffs[8 * i]);

        int16x8_t sign = vshrq_n_s16(vec_u, 15);
        sign = vandq_s16(sign, vec_q);
        vec_u = vaddq_s16(vec_u, sign);

        uint32x4_t d0 = vmovl_u16(vget_low_u16(vreinterpretq_u16_s16(vec_u)));
        uint32x4_t d1 = vmovl_u16(vget_high_u16(vreinterpretq_u16_s16(vec_u)));
        d0 = vshlq_n_u32(d0, 5); d0 = vaddq_u32(d0, vec_add);
        d1 = vshlq_n_u32(d1, 5); d1 = vaddq_u32(d1, vec_add);
        d0 = vmulq_u32(d0, vec_mul);
        d1 = vmulq_u32(d1, vec_mul);
        d0 = vshrq_n_u32(d0, 27);
        d1 = vshrq_n_u32(d1, 27);
        d0 = vandq_u32(d0, vdupq_n_u32(0x1F));
        d1 = vandq_u32(d1, vdupq_n_u32(0x1F));

        uint16x4_t n0 = vmovn_u32(d0);
        uint16x4_t n1 = vmovn_u32(d1);
        uint8x8_t t = vmovn_u16(vcombine_u16(n0, n1));

        
        uint8_t tmp[8];
        vst1_u8(tmp, t);

        r[0] = tmp[0] | (tmp[1] << 5);
        r[1] = (tmp[1] >> 3) | (tmp[2] << 2) | (tmp[3] << 7);
        r[2] = (tmp[3] >> 1) | (tmp[4] << 4);
        r[3] = (tmp[4] >> 4) | (tmp[5] << 1) | (tmp[6] << 6);
        r[4] = (tmp[6] >> 2) | (tmp[7] << 3);
        r += 5;
    }
#else
#error "KYBER_POLYCOMPRESSEDBYTES needs to be in {128, 160}"
#endif
}


void poly_decompress(poly *r, const uint8_t a[KYBER_POLYCOMPRESSEDBYTES])
{
    unsigned int i;
#if KYBER_POLYCOMPRESSEDBYTES == 128
    uint16x8_t vec_q = vdupq_n_u16(KYBER_Q);
    uint16x8_t vec_add = vdupq_n_u16(8);
    for (i = 0; i < KYBER_N / 8; i++) {
        uint8_t tmp[8];
        tmp[0] = a[0] & 0x0F; tmp[1] = a[0] >> 4;
        tmp[2] = a[1] & 0x0F; tmp[3] = a[1] >> 4;
        tmp[4] = a[2] & 0x0F; tmp[5] = a[2] >> 4;
        tmp[6] = a[3] & 0x0F; tmp[7] = a[3] >> 4;
        a += 4;

        // 向量计算 (t * Q + 8) >> 4
        uint8x8_t t_vec = vld1_u8(tmp);
        uint16x8_t d = vmovl_u8(t_vec);
        uint32x4_t lo = vmull_u16(vget_low_u16(d), vget_low_u16(vec_q));
        uint32x4_t hi = vmull_u16(vget_high_u16(d), vget_high_u16(vec_q));
        lo = vaddq_u32(lo, vmovl_u16(vget_low_u16(vec_add)));
        hi = vaddq_u32(hi, vmovl_u16(vget_high_u16(vec_add)));
        lo = vshrq_n_u32(lo, 4);
        hi = vshrq_n_u32(hi, 4);
        int16x4_t lo_s16 = vreinterpret_s16_u16(vmovn_u32(lo));
        int16x4_t hi_s16 = vreinterpret_s16_u16(vmovn_u32(hi));
        int16x8_t result = vcombine_s16(lo_s16, hi_s16);
        vst1q_s16(&r->coeffs[8 * i], result);
    }
#elif KYBER_POLYCOMPRESSEDBYTES == 160
    uint16x8_t vec_q16 = vdupq_n_u16(KYBER_Q);
    uint32x4_t vec_add = vdupq_n_u32(16);
    for (i = 0; i < KYBER_N / 8; i++) {
        uint8_t tmp[8];
        tmp[0] = a[0] & 31;
        tmp[1] = (a[0] >> 5) | (a[1] << 3);
        tmp[2] = a[1] >> 2;
        tmp[3] = (a[1] >> 7) | (a[2] << 1);
        tmp[4] = (a[2] >> 4) | (a[3] << 4);
        tmp[5] = a[3] >> 1;
        tmp[6] = (a[3] >> 6) | (a[4] << 2);
        tmp[7] = a[4] >> 3;
        a += 5;

        uint8x8_t t_vec = vld1_u8(tmp);
        uint16x8_t d = vmovl_u8(t_vec);
        uint32x4_t lo = vmull_u16(vget_low_u16(d), vget_low_u16(vec_q16));
        uint32x4_t hi = vmull_u16(vget_high_u16(d), vget_high_u16(vec_q16));
        lo = vaddq_u32(lo, vec_add);
        hi = vaddq_u32(hi, vec_add);
        lo = vshrq_n_u32(lo, 5);
        hi = vshrq_n_u32(hi, 5);
        int16x4_t lo_s16 = vreinterpret_s16_u16(vmovn_u32(lo));
        int16x4_t hi_s16 = vreinterpret_s16_u16(vmovn_u32(hi));
        int16x8_t result = vcombine_s16(lo_s16, hi_s16);
        vst1q_s16(&r->coeffs[8 * i], result);
    }
#endif
}

void poly_frombytes(poly *r, const uint8_t a[KYBER_POLYBYTES])
{
    unsigned int i;
    for (i = 0; i < KYBER_N / 8; i++) {
      
        uint16_t t[8];
        t[0] = (a[0] | ((uint16_t)a[1] << 8)) & 0xFFF;
        t[1] = ((a[1] >> 4) | ((uint16_t)a[2] << 4)) & 0xFFF;
        t[2] = (a[3] | ((uint16_t)a[4] << 8)) & 0xFFF;
        t[3] = ((a[4] >> 4) | ((uint16_t)a[5] << 4)) & 0xFFF;
        t[4] = (a[6] | ((uint16_t)a[7] << 8)) & 0xFFF;
        t[5] = ((a[7] >> 4) | ((uint16_t)a[8] << 4)) & 0xFFF;
        t[6] = (a[9] | ((uint16_t)a[10] << 8)) & 0xFFF;
        t[7] = ((a[10] >> 4) | ((uint16_t)a[11] << 4)) & 0xFFF;
        a += 12;

       
        vst1q_s16(&r->coeffs[8 * i], vreinterpretq_s16_u16(vld1q_u16(t)));
    }
}





void poly_tobytes(uint8_t r[KYBER_POLYBYTES], const poly *a)
{
    unsigned int i;
    int16x8_t vec_q = vdupq_n_s16(KYBER_Q);
    for (i = 0; i < KYBER_N / 8; i++) {
        int16x8_t vec_u = vld1q_s16(&a->coeffs[8 * i]);

        int16x8_t sign = vshrq_n_s16(vec_u, 15);
        sign = vandq_s16(sign, vec_q);
        vec_u = vaddq_s16(vec_u, sign);

        uint16x8_t u16 = vreinterpretq_u16_s16(vec_u);
        uint16x8_t low12 = vandq_u16(u16, vdupq_n_u16(0x0FFF));

     
        uint16_t tmp[8];
        vst1q_u16(tmp, low12);

        r[0] = tmp[0] & 0xFF;
        r[1] = (tmp[0] >> 8) | ((tmp[1] & 0x0F) << 4);
        r[2] = (tmp[1] >> 4) & 0xFF;
        r[3] = tmp[2] & 0xFF;
        r[4] = (tmp[2] >> 8) | ((tmp[3] & 0x0F) << 4);
        r[5] = (tmp[3] >> 4) & 0xFF;
        r[6] = tmp[4] & 0xFF;
        r[7] = (tmp[4] >> 8) | ((tmp[5] & 0x0F) << 4);
        r[8] = (tmp[5] >> 4) & 0xFF;
        r[9] = tmp[6] & 0xFF;
        r[10] = (tmp[6] >> 8) | ((tmp[7] & 0x0F) << 4);
        r[11] = (tmp[7] >> 4) & 0xFF;
        r += 12;
    }
}













void poly_frommsg(poly *r, const uint8_t msg[KYBER_INDCPA_MSGBYTES])
{
  unsigned int i,j;

#if (KYBER_INDCPA_MSGBYTES != KYBER_N/8)
#error "KYBER_INDCPA_MSGBYTES must be equal to KYBER_N/8 bytes!"
#endif

  for(i=0;i<KYBER_N/8;i++) {
    for(j=0;j<8;j++) {
      r->coeffs[8*i+j] = 0;
      cmov_int16(r->coeffs+8*i+j, ((KYBER_Q+1)/2), (msg[i] >> j)&1);
    }
  }
}






void poly_tomsg(uint8_t msg[KYBER_INDCPA_MSGBYTES], const poly *a)
{
  unsigned int i,j;
  uint32_t t;

  for(i=0;i<KYBER_N/8;i++) {
    msg[i] = 0;
    for(j=0;j<8;j++) {
      t  = a->coeffs[8*i+j];
      // t += ((int16_t)t >> 15) & KYBER_Q;
      // t  = (((t << 1) + KYBER_Q/2)/KYBER_Q) & 1;
      t <<= 1;
      t += 1665;
      t *= 80635;
      t >>= 28;
      t &= 1;
      msg[i] |= t << j;
    }
  }
}



void poly_getnoise_eta1(poly *r, const uint8_t seed[KYBER_SYMBYTES], uint8_t nonce)
{
  uint8_t buf[KYBER_ETA1*KYBER_N/4];
  prf(buf, sizeof(buf), seed, nonce);
  poly_cbd_eta1(r, buf);
}





void poly_getnoise_eta2(poly *r, const uint8_t seed[KYBER_SYMBYTES], uint8_t nonce)
{
  uint8_t buf[KYBER_ETA2*KYBER_N/4];
  prf(buf, sizeof(buf), seed, nonce);
  poly_cbd_eta2(r, buf);
}







void poly_ntt(poly *r)
{
  ntt(r->coeffs);
  poly_reduce(r);
}





void poly_invntt_tomont(poly *r)
{
  invntt(r->coeffs);
}




void poly_basemul_montgomery(poly *r, const poly *a, const poly *b)
{
  unsigned int i;
  for(i=0;i<KYBER_N/4;i++) {
    basemul(&r->coeffs[4*i], &a->coeffs[4*i], &b->coeffs[4*i], zetas[64+i]);
    basemul(&r->coeffs[4*i+2], &a->coeffs[4*i+2], &b->coeffs[4*i+2], -zetas[64+i]);
  }
}




void poly_tomont(poly *r)
{
    unsigned int i;
    const int16_t f = (1ULL << 32) % KYBER_Q;  // 保持原值

    
    int16x4_t f_vec = vdup_n_s16(f);

    
    for (i = 0; i < KYBER_N; i += 4) {
        
        int16x4_t coeffs = vld1_s16(&r->coeffs[i]);

        
        int32x4_t prod = vmull_s16(coeffs, f_vec);

      
        int16x4_t reduced = montgomery_reduce_neon(prod);

        
        vst1_s16(&r->coeffs[i], reduced);
    }
}



void poly_reduce(poly *r)
{
    unsigned int i;
    for (i = 0; i < KYBER_N; i += 8) {
        int16x8_t val = vld1q_s16(&r->coeffs[i]);
        val = barrett_reduce_neon(val);
        vst1q_s16(&r->coeffs[i], val);
    }
}







void poly_add(poly *r, const poly *a, const poly *b)
{
    unsigned int i;
    for (i = 0; i < KYBER_N / 8; i++) {
        int16x8_t va = vld1q_s16(&a->coeffs[8 * i]);
        int16x8_t vb = vld1q_s16(&b->coeffs[8 * i]);
        vst1q_s16(&r->coeffs[8 * i], vaddq_s16(va, vb));
    }
}



void poly_sub(poly *r, const poly *a, const poly *b)
{
    unsigned int i;
    for (i = 0; i < KYBER_N; i += 8) {
        int16x8_t va = vld1q_s16(&a->coeffs[i]);
        int16x8_t vb = vld1q_s16(&b->coeffs[i]);
        int16x8_t vr = vsubq_s16(va, vb);
        vst1q_s16(&r->coeffs[i], vr);
    }
}
