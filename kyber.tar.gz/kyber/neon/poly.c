#include <stdint.h>
#include "params.h"
#include "poly.h"
#include "ntt.h"
#include "reduce.h"
#include "cbd.h"
#include "symmetric.h"
#include <arm_neon.h>

static inline int16x8_t poly_decompress_8x_q5(const uint8_t t8[8])
{
  uint8x8_t raw = vld1_u8(t8);
  uint16x8_t tv = vmovl_u8(vand_u8(raw, vdup_n_u8(31)));
  uint32x4_t lo = vmovl_u16(vget_low_u16(tv));
  uint32x4_t hi = vmovl_u16(vget_high_u16(tv));
  lo = vmlaq_n_u32(vdupq_n_u32(16), lo, KYBER_Q);
  hi = vmlaq_n_u32(vdupq_n_u32(16), hi, KYBER_Q);

  return vreinterpretq_s16_u16(
      vcombine_u16(vmovn_u32(vshrq_n_u32(lo, 5)),
                   vmovn_u32(vshrq_n_u32(hi, 5))));
}

/* Kyber768/512：8 系数压缩到 4bit（与 ref 定点公式一致） */
static inline void poly_compress_fill_t_q4(uint8_t t[8], const int16_t *src)
{
  int16x8_t v = vld1q_s16(src);
  int16x8_t sign = vandq_s16(vshrq_n_s16(v, 15), vdupq_n_s16(KYBER_Q));
  uint16x8_t u = vreinterpretq_u16_s16(vaddq_s16(v, sign));

  uint32x4_t lo = vmovl_u16(vget_low_u16(u));
  uint32x4_t hi = vmovl_u16(vget_high_u16(u));
  lo = vshlq_n_u32(lo, 4);
  hi = vshlq_n_u32(hi, 4);
  lo = vaddq_u32(lo, vdupq_n_u32(1665));
  hi = vaddq_u32(hi, vdupq_n_u32(1665));
  lo = vmulq_n_u32(lo, 80635);
  hi = vmulq_n_u32(hi, 80635);
  lo = vshrq_n_u32(lo, 28);
  hi = vshrq_n_u32(hi, 28);

  uint16x8_t nib =
      vandq_u16(vcombine_u16(vmovn_u32(lo), vmovn_u32(hi)),
                vdupq_n_u16(0xF));
  vst1_u8(t, vmovn_u16(nib));
}

/* Kyber1024：8 系数压缩到 5bit */
static inline void poly_compress_fill_t_q5(uint8_t t[8], const int16_t *src)
{
  int16x8_t v = vld1q_s16(src);
  int16x8_t sign = vandq_s16(vshrq_n_s16(v, 15), vdupq_n_s16(KYBER_Q));
  uint16x8_t u = vreinterpretq_u16_s16(vaddq_s16(v, sign));

  uint32x4_t lo = vmovl_u16(vget_low_u16(u));
  uint32x4_t hi = vmovl_u16(vget_high_u16(u));
  lo = vshlq_n_u32(lo, 5);
  hi = vshlq_n_u32(hi, 5);
  lo = vaddq_u32(lo, vdupq_n_u32(1664));
  hi = vaddq_u32(hi, vdupq_n_u32(1664));
  lo = vmulq_n_u32(lo, 40318);
  hi = vmulq_n_u32(hi, 40318);
  lo = vshrq_n_u32(lo, 27);
  hi = vshrq_n_u32(hi, 27);

  uint16x8_t tw =
      vandq_u16(vcombine_u16(vmovn_u32(lo), vmovn_u32(hi)),
                vdupq_n_u16(0x1F));
  vst1_u8(t, vmovn_u16(tw));
}

/* 每 8 输入字节对应 16 个系数（q=4 解压） */
static inline void poly_decompress_8bytes_q4(int16_t *dst, const uint8_t *src)
{
  uint8x8_t b = vld1_u8(src);
  uint16x8_t w = vmovl_u8(b);
  uint16x8_t nlo = vandq_u16(w, vdupq_n_u16(15));
  uint16x8_t nhi = vshrq_n_u16(w, 4);

  uint32x4_t lo0 = vmovl_u16(vget_low_u16(nlo));
  uint32x4_t lo1 = vmovl_u16(vget_high_u16(nlo));
  uint32x4_t hi0 = vmovl_u16(vget_low_u16(nhi));
  uint32x4_t hi1 = vmovl_u16(vget_high_u16(nhi));

  lo0 = vmlaq_n_u32(vdupq_n_u32(8), lo0, KYBER_Q);
  lo1 = vmlaq_n_u32(vdupq_n_u32(8), lo1, KYBER_Q);
  hi0 = vmlaq_n_u32(vdupq_n_u32(8), hi0, KYBER_Q);
  hi1 = vmlaq_n_u32(vdupq_n_u32(8), hi1, KYBER_Q);
  lo0 = vshrq_n_u32(lo0, 4);
  lo1 = vshrq_n_u32(lo1, 4);
  hi0 = vshrq_n_u32(hi0, 4);
  hi1 = vshrq_n_u32(hi1, 4);

  int16x8_t out_lo =
      vcombine_s16(vmovn_s32(vreinterpretq_s32_u32(lo0)),
                   vmovn_s32(vreinterpretq_s32_u32(lo1)));
  int16x8_t out_hi =
      vcombine_s16(vmovn_s32(vreinterpretq_s32_u32(hi0)),
                   vmovn_s32(vreinterpretq_s32_u32(hi1)));

  {
    int16x8x2_t pair;
    pair.val[0] = out_lo;
    pair.val[1] = out_hi;
    vst2q_s16(dst, pair);
  }
}
/*poly_compress函数
c语言实现分为128字节和160字节两种情况。
1.将负数映射为正数。（方法是右移15位，和KYBER_Q 按位与后加到原数）
2.系数缩放到4bit(0~15)或者5bit(0~31)。8个系数打包为4字节或者5字节。
（方法是用定点数近似除法代替/3329*16或者/3329*32的浮点除法，避免精度损失。）
*/
/*neon优化思路
1.用 NEON 128 位寄存器批量加载 8 个系数（vld1q_s16）；
2.批量映射负数为正数；
3.批量执行缩放计算（移位 + 加法 + 乘法 + 右移）；
4.批量打包压缩后的 bit 到字节数组。
*/ 


void poly_compress(uint8_t r[KYBER_POLYCOMPRESSEDBYTES], const poly *a)
{
  unsigned int i;
  uint8_t t[8];

#if (KYBER_POLYCOMPRESSEDBYTES == 128)
  for (i = 0; i < KYBER_N / 8; i++) {
    poly_compress_fill_t_q4(t, &a->coeffs[8 * i]);

    r[0] = (uint8_t)(t[0] | (t[1] << 4));
    r[1] = (uint8_t)(t[2] | (t[3] << 4));
    r[2] = (uint8_t)(t[4] | (t[5] << 4));
    r[3] = (uint8_t)(t[6] | (t[7] << 4));
    r += 4;
  }
#elif (KYBER_POLYCOMPRESSEDBYTES == 160)
  for (i = 0; i < KYBER_N / 8; i++) {
    poly_compress_fill_t_q5(t, &a->coeffs[8 * i]);

    r[0] = (uint8_t)((t[0] >> 0) | (t[1] << 5));
    r[1] = (uint8_t)((t[1] >> 3) | (t[2] << 2) | (t[3] << 7));
    r[2] = (uint8_t)((t[3] >> 1) | (t[4] << 4));
    r[3] = (uint8_t)((t[4] >> 4) | (t[5] << 1) | (t[6] << 6));
    r[4] = (uint8_t)((t[6] >> 2) | (t[7] << 3));
    r += 5;
  }
#else
#error "KYBER_POLYCOMPRESSEDBYTES needs to be in {128, 160}"
#endif
}


void poly_decompress(poly *r, const uint8_t a[KYBER_POLYCOMPRESSEDBYTES])
{
  unsigned int i;

#if (KYBER_POLYCOMPRESSEDBYTES == 128)
  for (i = 0; i < KYBER_N / 16; i++) {
    poly_decompress_8bytes_q4(&r->coeffs[16 * i], &a[8 * i]);
  }
#elif (KYBER_POLYCOMPRESSEDBYTES == 160)
  uint8_t t[8];
  for(i=0;i<KYBER_N/8;i++) {
    t[0] = (a[0] >> 0);
    t[1] = (a[0] >> 5) | (a[1] << 3);
    t[2] = (a[1] >> 2);
    t[3] = (a[1] >> 7) | (a[2] << 1);
    t[4] = (a[2] >> 4) | (a[3] << 4);
    t[5] = (a[3] >> 1);
    t[6] = (a[3] >> 6) | (a[4] << 2);
    t[7] = (a[4] >> 3);
    a += 5;

    vst1q_s16(&r->coeffs[8*i], poly_decompress_8x_q5(t));
  }
#else
#error "KYBER_POLYCOMPRESSEDBYTES needs to be in {128, 160}"
#endif
}

void poly_frombytes(poly *r, const uint8_t a[KYBER_POLYBYTES])
{
    unsigned int i;
    for (i = 0; i < KYBER_N / 8; i++) {
      
        uint16_t t[8];
        t[0] = (a[0] | ((uint16_t)a[1] << 8)) & 0xFFF;
        t[1] = ((a[1] >> 4) | ((uint16_t)a[2] << 4)) & 0xFFF;
        t[2] = (a[3] | ((uint16_t)a[4] << 8)) & 0xFFF;
        t[3] = ((a[4] >> 4) | ((uint16_t)a[5] << 4)) & 0xFFF;
        t[4] = (a[6] | ((uint16_t)a[7] << 8)) & 0xFFF;
        t[5] = ((a[7] >> 4) | ((uint16_t)a[8] << 4)) & 0xFFF;
        t[6] = (a[9] | ((uint16_t)a[10] << 8)) & 0xFFF;
        t[7] = ((a[10] >> 4) | ((uint16_t)a[11] << 4)) & 0xFFF;
        a += 12;

       
        vst1q_s16(&r->coeffs[8 * i], vreinterpretq_s16_u16(vld1q_u16(t)));
    }
}





void poly_tobytes(uint8_t r[KYBER_POLYBYTES], const poly *a)
{
    unsigned int i;
    int16x8_t vec_q = vdupq_n_s16(KYBER_Q);
    for (i = 0; i < KYBER_N / 8; i++) {
        int16x8_t vec_u = vld1q_s16(&a->coeffs[8 * i]);

        int16x8_t sign = vshrq_n_s16(vec_u, 15);
        sign = vandq_s16(sign, vec_q);
        vec_u = vaddq_s16(vec_u, sign);

        uint16x8_t u16 = vreinterpretq_u16_s16(vec_u);
        uint16x8_t low12 = vandq_u16(u16, vdupq_n_u16(0x0FFF));

     
        uint16_t tmp[8];
        vst1q_u16(tmp, low12);

        r[0] = tmp[0] & 0xFF;
        r[1] = (tmp[0] >> 8) | ((tmp[1] & 0x0F) << 4);
        r[2] = (tmp[1] >> 4) & 0xFF;
        r[3] = tmp[2] & 0xFF;
        r[4] = (tmp[2] >> 8) | ((tmp[3] & 0x0F) << 4);
        r[5] = (tmp[3] >> 4) & 0xFF;
        r[6] = tmp[4] & 0xFF;
        r[7] = (tmp[4] >> 8) | ((tmp[5] & 0x0F) << 4);
        r[8] = (tmp[5] >> 4) & 0xFF;
        r[9] = tmp[6] & 0xFF;
        r[10] = (tmp[6] >> 8) | ((tmp[7] & 0x0F) << 4);
        r[11] = (tmp[7] >> 4) & 0xFF;
        r += 12;
    }
}













void poly_frommsg(poly *r, const uint8_t msg[KYBER_INDCPA_MSGBYTES])
{
  unsigned int i;

#if (KYBER_INDCPA_MSGBYTES != KYBER_N/8)
#error "KYBER_INDCPA_MSGBYTES must be equal to KYBER_N/8 bytes!"
#endif

  for (i = 0; i < KYBER_N / 8; i++) {
    uint16_t bits[8];
    uint8_t m = msg[i];

    bits[0] = (uint16_t)((m >> 0) & 1);
    bits[1] = (uint16_t)((m >> 1) & 1);
    bits[2] = (uint16_t)((m >> 2) & 1);
    bits[3] = (uint16_t)((m >> 3) & 1);
    bits[4] = (uint16_t)((m >> 4) & 1);
    bits[5] = (uint16_t)((m >> 5) & 1);
    bits[6] = (uint16_t)((m >> 6) & 1);
    bits[7] = (uint16_t)((m >> 7) & 1);

    uint16x8_t bv = vld1q_u16(bits);
    uint16x8_t out =
        vmulq_n_u16(bv, (uint16_t)((KYBER_Q + 1) / 2));
    vst1q_s16(&r->coeffs[8 * i], vreinterpretq_s16_u16(out));
  }
}






void poly_tomsg(uint8_t msg[KYBER_INDCPA_MSGBYTES], const poly *a)
{
  unsigned int i;

  for (i = 0; i < KYBER_N / 8; i++) {
    int16x8_t v = vld1q_s16(&a->coeffs[8 * i]);
    int32x4_t slo = vmovl_s16(vget_low_s16(v));
    int32x4_t shi = vmovl_s16(vget_high_s16(v));
    uint32x4_t tlo = vreinterpretq_u32_s32(slo);
    uint32x4_t thi = vreinterpretq_u32_s32(shi);

    tlo = vshlq_n_u32(tlo, 1);
    thi = vshlq_n_u32(thi, 1);
    tlo = vaddq_u32(tlo, vdupq_n_u32(1665));
    thi = vaddq_u32(thi, vdupq_n_u32(1665));
    tlo = vmulq_n_u32(tlo, 80635);
    thi = vmulq_n_u32(thi, 80635);
    tlo = vshrq_n_u32(tlo, 28);
    thi = vshrq_n_u32(thi, 28);
    tlo = vandq_u32(tlo, vdupq_n_u32(1));
    thi = vandq_u32(thi, vdupq_n_u32(1));

    msg[i] = (uint8_t)(
        vgetq_lane_u32(tlo, 0) | (vgetq_lane_u32(tlo, 1) << 1)
        | (vgetq_lane_u32(tlo, 2) << 2) | (vgetq_lane_u32(tlo, 3) << 3)
        | (vgetq_lane_u32(thi, 0) << 4) | (vgetq_lane_u32(thi, 1) << 5)
        | (vgetq_lane_u32(thi, 2) << 6) | (vgetq_lane_u32(thi, 3) << 7));
  }
}



void poly_getnoise_eta1(poly *r, const uint8_t seed[KYBER_SYMBYTES], uint8_t nonce)
{
  uint8_t buf[KYBER_ETA1*KYBER_N/4];
  prf(buf, sizeof(buf), seed, nonce);
  poly_cbd_eta1(r, buf);
}





void poly_getnoise_eta2(poly *r, const uint8_t seed[KYBER_SYMBYTES], uint8_t nonce)
{
  uint8_t buf[KYBER_ETA2*KYBER_N/4];
  prf(buf, sizeof(buf), seed, nonce);
  poly_cbd_eta2(r, buf);
}







void poly_ntt(poly *r)
{
  ntt(r->coeffs);
  poly_reduce(r);
}





void poly_invntt_tomont(poly *r)
{
  invntt(r->coeffs);
}




/* 8-coeff NEON basemul: process two adjacent 4-coeff blocks (zetas z0, z1)
   in a single 128-bit register. Output matches two pairs of ref basemul calls
   with signs {+z0, -z0} and {+z1, -z1}. */
static inline int16x8_t basemul_neon_8coeff_vec(int16x8_t va, int16x8_t vb,
                                                int16_t z0, int16_t z1)
{
  /* Swap within each 32-bit lane: per 4-coeff block [b0,b1,B0,B1] -> [b1,b0,B1,B0]. */
  int16x8_t vb_sw = vrev32q_s16(vb);

  int16x4_t uu_lo = montgomery_reduce_neon(vmull_s16(vget_low_s16(va),  vget_low_s16(vb)));
  int16x4_t uu_hi = montgomery_reduce_neon(vmull_high_s16(va, vb));
  int16x8_t uu = vcombine_s16(uu_lo, uu_hi);

  int16x4_t cc_lo = montgomery_reduce_neon(vmull_s16(vget_low_s16(va),  vget_low_s16(vb_sw)));
  int16x4_t cc_hi = montgomery_reduce_neon(vmull_high_s16(va, vb_sw));
  int16x8_t cc = vcombine_s16(cc_lo, cc_hi);

  /* zvec = [z0, z0, -z0, -z0, z1, z1, -z1, -z1] */
  int32x2_t z0p = vreinterpret_s32_s16(vdup_n_s16(z0));
  int32x2_t z0n = vreinterpret_s32_s16(vdup_n_s16((int16_t)(-z0)));
  int32x2_t z1p = vreinterpret_s32_s16(vdup_n_s16(z1));
  int32x2_t z1n = vreinterpret_s32_s16(vdup_n_s16((int16_t)(-z1)));
  int16x4_t zvec_lo = vreinterpret_s16_s32(vzip1_s32(z0p, z0n));
  int16x4_t zvec_hi = vreinterpret_s16_s32(vzip1_s32(z1p, z1n));
  int16x8_t zvec = vcombine_s16(zvec_lo, zvec_hi);

  int16x4_t fz_lo = montgomery_reduce_neon(vmull_s16(vget_low_s16(uu),  vget_low_s16(zvec)));
  int16x4_t fz_hi = montgomery_reduce_neon(vmull_high_s16(uu, zvec));
  int16x8_t fz = vcombine_s16(fz_lo, fz_hi);

  /* even lanes of (uu + rev32(fz)) hold r[0]/r[2]/r[4]/r[6]. */
  int16x8_t even_sum = vaddq_s16(uu, vrev32q_s16(fz));
  int16x8_t even = vuzp1q_s16(even_sum, even_sum);
  /* odd values from pair-sum of cc hold r[1]/r[3]/r[5]/r[7]. */
  int16x8_t odd  = vpaddq_s16(cc, cc);

  return vzip1q_s16(even, odd);
}

void poly_basemul_montgomery(poly *r, const poly *a, const poly *b)
{
  unsigned int i;

  for (i = 0; i < KYBER_N / 4; i += 2) {
    int16x8_t va = vld1q_s16(&a->coeffs[4 * i]);
    int16x8_t vb = vld1q_s16(&b->coeffs[4 * i]);
    int16x8_t out = basemul_neon_8coeff_vec(va, vb,
                                            zetas[64 + i], zetas[64 + i + 1]);
    vst1q_s16(&r->coeffs[4 * i], out);
  }
}

void poly_basemul_montgomery_acc(poly *r, const poly *a, const poly *b)
{
  unsigned int i;

  for (i = 0; i < KYBER_N / 4; i += 2) {
    int16x8_t va = vld1q_s16(&a->coeffs[4 * i]);
    int16x8_t vb = vld1q_s16(&b->coeffs[4 * i]);
    int16x8_t vr = vld1q_s16(&r->coeffs[4 * i]);
    int16x8_t out = basemul_neon_8coeff_vec(va, vb,
                                            zetas[64 + i], zetas[64 + i + 1]);
    vst1q_s16(&r->coeffs[4 * i], vaddq_s16(vr, out));
  }
}




void poly_tomont(poly *r)
{
    unsigned int i;
    const int16_t f = (1ULL << 32) % KYBER_Q;  // 保持原值

    
    int16x4_t f_vec = vdup_n_s16(f);

    
    for (i = 0; i < KYBER_N; i += 4) {
        
        int16x4_t coeffs = vld1_s16(&r->coeffs[i]);

        
        int32x4_t prod = vmull_s16(coeffs, f_vec);

      
        int16x4_t reduced = montgomery_reduce_neon(prod);

        
        vst1_s16(&r->coeffs[i], reduced);
    }
}



void poly_reduce(poly *r)
{
    unsigned int i;
    for (i = 0; i < KYBER_N; i += 8) {
        int16x8_t val = vld1q_s16(&r->coeffs[i]);
        val = barrett_reduce_neon(val);
        vst1q_s16(&r->coeffs[i], val);
    }
}







void poly_add(poly *r, const poly *a, const poly *b)
{
    unsigned int i;
    for (i = 0; i < KYBER_N / 8; i++) {
        int16x8_t va = vld1q_s16(&a->coeffs[8 * i]);
        int16x8_t vb = vld1q_s16(&b->coeffs[8 * i]);
        vst1q_s16(&r->coeffs[8 * i], vaddq_s16(va, vb));
    }
}



void poly_sub(poly *r, const poly *a, const poly *b)
{
    unsigned int i;
    for (i = 0; i < KYBER_N; i += 8) {
        int16x8_t va = vld1q_s16(&a->coeffs[i]);
        int16x8_t vb = vld1q_s16(&b->coeffs[i]);
        int16x8_t vr = vsubq_s16(va, vb);
        vst1q_s16(&r->coeffs[i], vr);
    }
}
