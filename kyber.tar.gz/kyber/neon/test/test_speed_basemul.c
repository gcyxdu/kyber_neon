#include <stdint.h>
#include <stdio.h>
#include "../params.h"
#include "../poly.h"
#include "../polyvec.h"
#include "cpucycles.h"
#include "speed_print.h"

#define NTESTS 1000

static uint64_t t_total[NTESTS];
static uint64_t t_first_mul[NTESTS];
static uint64_t t_rest_mul[NTESTS];
static uint64_t t_rest_add[NTESTS];
static uint64_t t_reduce[NTESTS];
static volatile int16_t sink;

static void init_polyvec(polyvec *v, int16_t base)
{
  unsigned int i, j;
  for(i = 0; i < KYBER_K; i++) {
    for(j = 0; j < KYBER_N; j++) {
      v->vec[i].coeffs[j] = (int16_t)(base + 13 * (int16_t)i + (int16_t)(j & 0x0f));
    }
  }
}

int main(void)
{
  unsigned int i, j;
  polyvec a, b;
  poly acc;
  poly tmp[KYBER_K - 1];

  init_polyvec(&a, 1);
  init_polyvec(&b, 7);

  /* CPU warmup to saturate DVFS before measuring with CNTVCT_EL0. */
  {
    volatile uint64_t warm = 0;
    for (i = 0; i < 2000000u; i++) warm += i;
    (void)warm;
  }

  for(i = 0; i < NTESTS; i++) {
    t_total[i] = cpucycles();
    polyvec_basemul_acc_montgomery(&acc, &a, &b);
    sink ^= acc.coeffs[0];
  }
  print_results("polyvec_basemul_acc_montgomery (total): ", t_total, NTESTS);

  for(i = 0; i < NTESTS; i++) {
    t_first_mul[i] = cpucycles();
    poly_basemul_montgomery(&acc, &a.vec[0], &b.vec[0]);
    sink ^= acc.coeffs[1];
  }
  print_results("polyvec_basemul_acc_montgomery (first mul): ", t_first_mul, NTESTS);

  for(i = 0; i < NTESTS; i++) {
    poly_basemul_montgomery(&acc, &a.vec[0], &b.vec[0]);
    t_rest_mul[i] = cpucycles();
    for(j = 1; j < KYBER_K; j++) {
      poly_basemul_montgomery(&tmp[j - 1], &a.vec[j], &b.vec[j]);
    }
    sink ^= tmp[KYBER_K - 2].coeffs[0];
  }
  print_results("polyvec_basemul_acc_montgomery (rest mul loop): ", t_rest_mul, NTESTS);

  for(i = 0; i < NTESTS; i++) {
    poly_basemul_montgomery(&acc, &a.vec[0], &b.vec[0]);
    for(j = 1; j < KYBER_K; j++) {
      poly_basemul_montgomery(&tmp[j - 1], &a.vec[j], &b.vec[j]);
    }
    t_rest_add[i] = cpucycles();
    for(j = 1; j < KYBER_K; j++) {
      poly_add(&acc, &acc, &tmp[j - 1]);
    }
    sink ^= acc.coeffs[2];
  }
  print_results("polyvec_basemul_acc_montgomery (rest add loop): ", t_rest_add, NTESTS);

  for(i = 0; i < NTESTS; i++) {
    poly_basemul_montgomery(&acc, &a.vec[0], &b.vec[0]);
    for(j = 1; j < KYBER_K; j++) {
      poly_basemul_montgomery(&tmp[j - 1], &a.vec[j], &b.vec[j]);
      poly_add(&acc, &acc, &tmp[j - 1]);
    }
    t_reduce[i] = cpucycles();
    poly_reduce(&acc);
    sink ^= acc.coeffs[3];
  }
  print_results("polyvec_basemul_acc_montgomery (final reduce): ", t_reduce, NTESTS);

  return (int)sink;
}
