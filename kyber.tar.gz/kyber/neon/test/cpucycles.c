#include "cpucycles.h"

uint64_t cpucycles_overhead(void) {
    return 0;
}

uint64_t cpucycles_reference(void) {
    return cpucycles();
}

