#ifndef CPUCYCLES_H
#define CPUCYCLES_H

#include <stdint.h>
#include <unistd.h>

#if defined(__aarch64__)

static inline uint64_t cpucycles(void) {
    uint64_t val;
    __asm__ volatile("mrs %0, cntvct_el0" : "=r"(val));
    return val;
}
#elif defined(__x86_64__)

static inline uint64_t cpucycles(void) {
    unsigned int hi, lo;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}
#else
#error "Unsupported architecture"
#endif


uint64_t cpucycles_overhead(void);
uint64_t cpucycles_reference(void);

#endif
