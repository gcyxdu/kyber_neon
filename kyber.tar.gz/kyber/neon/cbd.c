#include <stdint.h>
#include <arm_neon.h>
#include "params.h"
#include "cbd.h"

#if KYBER_ETA1 == 3
/*************************************************
* Name:        load24_littleendian
**************************************************/
static uint32_t load24_littleendian(const uint8_t x[3])
{
  uint32_t r;
  r  = (uint32_t)x[0];
  r |= (uint32_t)x[1] << 8;
  r |= (uint32_t)x[2] << 16;
  return r;
}
#endif

/* eta=2：由 d 写出 8 个系数（与 ref 逐位等价） */
static inline void cbd2_write8(int16_t *r, uint32_t d)
{
  r[0] = (int16_t)((d >>  0) & 3) - (int16_t)((d >>  2) & 3);
  r[1] = (int16_t)((d >>  4) & 3) - (int16_t)((d >>  6) & 3);
  r[2] = (int16_t)((d >>  8) & 3) - (int16_t)((d >> 10) & 3);
  r[3] = (int16_t)((d >> 12) & 3) - (int16_t)((d >> 14) & 3);
  r[4] = (int16_t)((d >> 16) & 3) - (int16_t)((d >> 18) & 3);
  r[5] = (int16_t)((d >> 20) & 3) - (int16_t)((d >> 22) & 3);
  r[6] = (int16_t)((d >> 24) & 3) - (int16_t)((d >> 26) & 3);
  r[7] = (int16_t)((d >> 28) & 3) - (int16_t)((d >> 30) & 3);
}

#if KYBER_ETA1 == 3
/* eta=3（仅 Kyber-512）：由 d 写出 4 个系数 */
static inline void cbd3_write4(int16_t *r, uint32_t d)
{
  r[0] = (int16_t)((d >>  0) & 7) - (int16_t)((d >>  3) & 7);
  r[1] = (int16_t)((d >>  6) & 7) - (int16_t)((d >>  9) & 7);
  r[2] = (int16_t)((d >> 12) & 7) - (int16_t)((d >> 15) & 7);
  r[3] = (int16_t)((d >> 18) & 7) - (int16_t)((d >> 21) & 7);
}
#endif

/*************************************************
* Name:        cbd2
**************************************************/
static void cbd2(poly *r, const uint8_t buf[2 * KYBER_N / 4])
{
  const uint32x4_t mask555 = vdupq_n_u32(0x55555555u);

  unsigned int i;
  for (i = 0; i < KYBER_N / 8; i += 4) {
    uint32x4_t t = vld1q_u32((const uint32_t *)(const void *)(buf + 4 * i));
    uint32x4_t d = vaddq_u32(vandq_u32(t, mask555),
                             vandq_u32(vshrq_n_u32(t, 1), mask555));

    cbd2_write8(&r->coeffs[8 * i +  0], vgetq_lane_u32(d, 0));
    cbd2_write8(&r->coeffs[8 * i +  8], vgetq_lane_u32(d, 1));
    cbd2_write8(&r->coeffs[8 * i + 16], vgetq_lane_u32(d, 2));
    cbd2_write8(&r->coeffs[8 * i + 24], vgetq_lane_u32(d, 3));
  }
}

#if KYBER_ETA1 == 3
/*************************************************
* Name:        cbd3
**************************************************/
static void cbd3(poly *r, const uint8_t buf[3 * KYBER_N / 4])
{
  unsigned int i;
  uint32_t t, d;

  for (i = 0; i < KYBER_N / 4; i++) {
    t = load24_littleendian(buf + 3 * i);
    d = t & 0x00249249;
    d += (t >> 1) & 0x00249249;
    d += (t >> 2) & 0x00249249;

    cbd3_write4(&r->coeffs[4 * i], d);
  }
}
#endif

void poly_cbd_eta1(poly *r, const uint8_t buf[KYBER_ETA1 * KYBER_N / 4])
{
#if KYBER_ETA1 == 2
  cbd2(r, buf);
#elif KYBER_ETA1 == 3
  cbd3(r, buf);
#else
#error "This implementation requires eta1 in {2,3}"
#endif
}

void poly_cbd_eta2(poly *r, const uint8_t buf[KYBER_ETA2 * KYBER_N / 4])
{
#if KYBER_ETA2 == 2
  cbd2(r, buf);
#else
#error "This implementation requires eta2 = 2"
#endif
}
