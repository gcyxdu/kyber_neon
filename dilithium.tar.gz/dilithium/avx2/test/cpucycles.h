#ifndef CPUCYCLES_H
#define CPUCYCLES_H

#include <stdint.h>

// ARM64 (aarch64) 读取系统计数器（替换x86的rdtsc）
static inline uint64_t cpucycles(void) {
  uint64_t val;
  __asm__ volatile ("mrs %0, cntvct_el0" : "=r" (val));
  return val;
}

// 保留原有的overhead函数声明（cpucycles.c会调用）
uint64_t cpucycles_overhead(void);

#endif
