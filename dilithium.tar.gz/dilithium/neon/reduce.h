#ifndef REDUCE_H
#define REDUCE_H

#include <stdint.h>
#include "params.h"
#include <arm_neon.h>

#define MONT -4186625 // 2^32 % Q
#define QINV 58728449 // q^(-1) mod 2^32

#define montgomery_reduce DILITHIUM_NAMESPACE(montgomery_reduce)
int32_t montgomery_reduce(int64_t a);

#define reduce32 DILITHIUM_NAMESPACE(reduce32)
int32_t reduce32(int32_t a);

#define caddq DILITHIUM_NAMESPACE(caddq)
int32_t caddq(int32_t a);

#define freeze DILITHIUM_NAMESPACE(freeze)
int32_t freeze(int32_t a);

#define montgomery_reduce_neon_4 DILITHIUM_NAMESPACE(montgomery_reduce_neon_4)
int32x4_t montgomery_reduce_neon_4(int64x2x2_t a) ;

/* 纯 NEON Montgomery 约简：一次处理 4 个 64-bit 乘积（拆成两个 int64x2_t）。
 * 对应 ref 版标量公式：
 *   t = (int32_t)a * QINV;
 *   r = (a - (int64_t)t * Q) >> 32;
 * 使用 vsubq_s64 + vshrn_n_s64 避免 lane 提取到标量。
 * 标记 static inline 以便在 ntt/poly 的热点循环里被内联。
 */
static inline int32x4_t montgomery_reduce_2x(int64x2_t a0, int64x2_t a1) {
    int32x2_t low0 = vmovn_s64(a0);
    int32x2_t low1 = vmovn_s64(a1);

    int32x2_t t0 = vmul_n_s32(low0, QINV);
    int32x2_t t1 = vmul_n_s32(low1, QINV);

    int64x2_t u0 = vmull_n_s32(t0, Q);
    int64x2_t u1 = vmull_n_s32(t1, Q);

    int64x2_t r0 = vsubq_s64(a0, u0);
    int64x2_t r1 = vsubq_s64(a1, u1);

    return vcombine_s32(vshrn_n_s64(r0, 32), vshrn_n_s64(r1, 32));
}


#define reduce32_neon_4 DILITHIUM_NAMESPACE(reduce32_neon_4)
int32x4_t reduce32_neon_4(int32x4_t a);


#define caddq_neon_4 DILITHIUM_NAMESPACE(caddq_neon_4)
int32x4_t caddq_neon_4(int32x4_t a);

#define freeze_neon_4 DILITHIUM_NAMESPACE(freeze_neon_4)
int32x4_t freeze_neon_4(int32x4_t a);
#endif
