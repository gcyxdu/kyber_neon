#include <stdint.h>
#include "params.h"
#include "rejsample.h"
#include <arm_neon.h>

/*************************************************
* Name:        rej_uniform_neon
*
* Description: Same as scalar rej_uniform, but processes four 24-bit
*              candidates per iteration when possible (Cortex-A53).
**************************************************/
unsigned int rej_uniform_neon(int32_t *a,
                              unsigned int len,
                              const uint8_t *buf,
                              unsigned int buflen)
{
  unsigned int ctr, pos;
  const uint32x4_t qv = vdupq_n_u32(Q);

  ctr = 0;
  pos = 0;

  while(ctr + 4 <= len && pos + 12 <= buflen) {
    uint32_t t0, t1, t2, t3;

    t0 = (uint32_t)buf[pos + 0]
       | ((uint32_t)buf[pos + 1] << 8)
       | ((uint32_t)buf[pos + 2] << 16);
    t0 &= 0x7FFFFF;
    t1 = (uint32_t)buf[pos + 3]
       | ((uint32_t)buf[pos + 4] << 8)
       | ((uint32_t)buf[pos + 5] << 16);
    t1 &= 0x7FFFFF;
    t2 = (uint32_t)buf[pos + 6]
       | ((uint32_t)buf[pos + 7] << 8)
       | ((uint32_t)buf[pos + 8] << 16);
    t2 &= 0x7FFFFF;
    t3 = (uint32_t)buf[pos + 9]
       | ((uint32_t)buf[pos + 10] << 8)
       | ((uint32_t)buf[pos + 11] << 16);
    t3 &= 0x7FFFFF;
    pos += 12;

    {
      uint32x2_t lo = vcreate_u32(((uint64_t)t1 << 32) | (uint64_t)t0);
      uint32x2_t hi = vcreate_u32(((uint64_t)t3 << 32) | (uint64_t)t2);
      uint32x4_t tv = vcombine_u32(lo, hi);
      uint32x4_t ok = vcltq_u32(tv, qv);
      unsigned k;

      for(k = 0; k < 4; k++) {
        if(vgetq_lane_u32(ok, k))
          a[ctr++] = (int32_t)vgetq_lane_u32(tv, k);
      }
    }
  }

  while(ctr < len && pos + 3 <= buflen) {
    uint32_t t;

    t  = buf[pos++];
    t |= (uint32_t)buf[pos++] << 8;
    t |= (uint32_t)buf[pos++] << 16;
    t &= 0x7FFFFF;

    if(t < (uint32_t)Q)
      a[ctr++] = (int32_t)t;
  }

  return ctr;
}
