#ifndef DILITHIUM_REJSAMPLE_H
#define DILITHIUM_REJSAMPLE_H

#include <stdint.h>
#include "config.h"

/* NEON batch rejection for ExpandA (poly_uniform). Must match scalar rej_uniform. */
#define rej_uniform_neon DILITHIUM_NAMESPACE(rej_uniform_neon)
unsigned int rej_uniform_neon(int32_t *a,
                              unsigned int len,
                              const uint8_t *buf,
                              unsigned int buflen);

#endif
