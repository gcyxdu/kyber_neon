#include "reduce.h"
#include <arm_neon.h>

// ref
int32_t montgomery_reduce(int64_t a) {
  int32_t t = (int32_t)a * QINV;
  t = (a - (int64_t)t * Q) >> 32;
  return t;
}

int32_t reduce32(int32_t a) {
  int32_t t = (a + (1 << 22)) >> 23;
  return a - t * Q;
}

int32_t caddq(int32_t a) {
  return a + ((a >> 31) & Q);
}

int32_t freeze(int32_t a) {
  return caddq(reduce32(a));
}

/* 保持原 API 兼容：薄封装，直接转发到纯 NEON 内联版本。
 * 原实现里 a-u 和 >>32 走了 lane 提取到标量，性能很差；
 * 现在统一走 vsubq_s64 + vshrn_n_s64（见 reduce.h 中的 montgomery_reduce_2x）。
 */
int32x4_t montgomery_reduce_neon_4(int64x2x2_t inp) {
    return montgomery_reduce_2x(inp.val[0], inp.val[1]);
}



// NEON reduce32（4 个系数）
int32x4_t reduce32_neon_4(int32x4_t a) {
  int32x4_t shift22 = vdupq_n_s32(1 << 22);
  int32x4_t q = vdupq_n_s32(Q);

  int32x4_t t = vaddq_s32(a, shift22);
  t = vshrq_n_s32(t, 23);

  int32x4_t tq = vmulq_s32(t, q);
  return vsubq_s32(a, tq);
}

// NEON caddq（4 个系数）
int32x4_t caddq_neon_4(int32x4_t a) {
  int32x4_t q = vdupq_n_s32(Q);
  int32x4_t sign = vshrq_n_s32(a, 31);
  int32x4_t add = vandq_s32(sign, q);
  return vaddq_s32(a, add);
}

// NEON freeze = reduce32 + caddq（4 个系数）
int32x4_t freeze_neon_4(int32x4_t a) {
  a = reduce32_neon_4(a);
  a = caddq_neon_4(a);
  return a;
}
