#include "reduce.h"
#include <arm_neon.h>

// ref
int32_t montgomery_reduce(int64_t a) {
  int32_t t = (int32_t)a * QINV;
  t = (a - (int64_t)t * Q) >> 32;
  return t;
}

int32_t reduce32(int32_t a) {
  int32_t t = (a + (1 << 22)) >> 23;
  return a - t * Q;
}

int32_t caddq(int32_t a) {
  return a + ((a >> 31) & Q);
}

int32_t freeze(int32_t a) {
  return caddq(reduce32(a));
}

// 在 reduce.c 中替换原来的 montgomery_reduce_neon_4
int32x4_t montgomery_reduce_neon_4(int64x2x2_t inp) {
    int64x2_t a0 = inp.val[0];  // 前两个 64-bit
    int64x2_t a1 = inp.val[1];  // 后两个 64-bit

    // 第一步：低 32 位乘 QINV
    int32x2_t low0 = vmovn_s64(a0);
    int32x2_t low1 = vmovn_s64(a1);
    int32x4_t low_all = vcombine_s32(low0, low1);

    int32x2_t t0 = vmul_n_s32(vget_low_s32(low_all),  QINV);
    int32x2_t t1 = vmul_n_s32(vget_high_s32(low_all), QINV);

    // 第二步：t * Q（产生两个 int64x2_t）
    int64x2_t u0 = vmull_n_s32(t0, Q);
    int64x2_t u1 = vmull_n_s32(t1, Q);

    // 第三步：a - u（因为 vsub_s64 只支持 1-lane，所以拆开处理）
    int64_t a0_0 = vgetq_lane_s64(a0, 0);
    int64_t a0_1 = vgetq_lane_s64(a0, 1);
    int64_t a1_0 = vgetq_lane_s64(a1, 0);
    int64_t a1_1 = vgetq_lane_s64(a1, 1);

    int64_t u0_0 = vgetq_lane_s64(u0, 0);
    int64_t u0_1 = vgetq_lane_s64(u0, 1);
    int64_t u1_0 = vgetq_lane_s64(u1, 0);
    int64_t u1_1 = vgetq_lane_s64(u1, 1);

    int64_t res0_0 = a0_0 - u0_0;
    int64_t res0_1 = a0_1 - u0_1;
    int64_t res1_0 = a1_0 - u1_0;
    int64_t res1_1 = a1_1 - u1_1;

    // 第四步：>> 32 并合并成 int32x4_t
    int32_t r0_0 = (int32_t)(res0_0 >> 32);
    int32_t r0_1 = (int32_t)(res0_1 >> 32);
    int32_t r1_0 = (int32_t)(res1_0 >> 32);
    int32_t r1_1 = (int32_t)(res1_1 >> 32);

    int32x2_t r0 = vcreate_s32(((uint64_t)r0_1 << 32) | (uint32_t)r0_0);
    int32x2_t r1 = vcreate_s32(((uint64_t)r1_1 << 32) | (uint32_t)r1_0);

    return vcombine_s32(r0, r1);
}



// NEON reduce32（4 个系数）
int32x4_t reduce32_neon_4(int32x4_t a) {
  int32x4_t shift22 = vdupq_n_s32(1 << 22);
  int32x4_t q = vdupq_n_s32(Q);

  int32x4_t t = vaddq_s32(a, shift22);
  t = vshrq_n_s32(t, 23);

  int32x4_t tq = vmulq_s32(t, q);
  return vsubq_s32(a, tq);
}

// NEON caddq（4 个系数）
int32x4_t caddq_neon_4(int32x4_t a) {
  int32x4_t q = vdupq_n_s32(Q);
  int32x4_t sign = vshrq_n_s32(a, 31);
  int32x4_t add = vandq_s32(sign, q);
  return vaddq_s32(a, add);
}

// NEON freeze = reduce32 + caddq（4 个系数）
int32x4_t freeze_neon_4(int32x4_t a) {
  a = reduce32_neon_4(a);
  a = caddq_neon_4(a);
  return a;
}
